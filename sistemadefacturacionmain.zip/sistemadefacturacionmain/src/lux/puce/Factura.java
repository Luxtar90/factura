package lux.puce;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;

public class Factura extends JInternalFrame {
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTable tableproductos;
	private DefaultTableModel model;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Productos frame = new Productos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Factura() {
		setTitle("FACTURA");
		getContentPane().setBackground(new Color(128, 255, 255));
		setBounds(100, 100, 750, 449);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("nombre:");
		lblNewLabel.setBounds(30, 31, 76, 19);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("ID:");
		lblNewLabel_1.setBounds(30, 61, 76, 14);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("address:");
		lblNewLabel_2.setBounds(30, 86, 87, 14);
		getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("telefono:");
		lblNewLabel_3.setBounds(30, 111, 76, 14);
		getContentPane().add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(89, 30, 117, 20);
		getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(89, 58, 117, 20);
		getContentPane().add(textField_1);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(89, 83, 117, 20);
		getContentPane().add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(89, 108, 117, 20);
		getContentPane().add(textField_3);
		
		JButton btnNewButton = new JButton("New");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textField.setText("");
				textField_1.setText("");
				textField_2.setText("");
				textField_3.setText("");
			}
		});
		btnNewButton.setBounds(216, 82, 63, 23);
		getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("buscar cliente");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Producto producto = new Producto();
				producto.setCodigo(textField.getText());
				producto.setCantidad (Float.parseFloat(textField_1.getText()));
				producto.setDescripcion(textField_2.getText());
				producto.setPrecio (Float.parseFloat(textField_3.getText()));
				producto.setTotal(producto.getCantidad()*producto.getPrecio());
				
				Object[]fila = new Object[5];
				fila[0] = producto.getCodigo();
				fila[1] = producto.getCantidad();
				fila[2] = producto.getDescripcion();
				fila[3] = producto.getPrecio();
				fila[4] = producto.getTotal();
				model.addRow(fila);
			
			}
			

		});
		btnNewButton_1.setBounds(216, 29, 147, 35);
		getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("delete");
		btnNewButton_2.setForeground(new Color(255, 0, 0));
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnNewButton_2.setBounds(289, 82, 76, 23);
		getContentPane().add(btnNewButton_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 136, 396, 161);
		getContentPane().add(scrollPane);
		
		tableproductos = new JTable();
		tableproductos.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"COD", "detalle", "Price","Cantidad","iva","totaliva", "Total"
			}
		));
		scrollPane.setViewportView(tableproductos);
		
		JLabel lblNewLabel_4 = new JLabel("numb_fact:");
		lblNewLabel_4.setBounds(544, 11, 63, 14);
		getContentPane().add(lblNewLabel_4);
		
		textField_4 = new JTextField();
		textField_4.setBounds(602, 8, 86, 20);
		getContentPane().add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("fecha:");
		lblNewLabel_5.setBounds(570, 33, 46, 14);
		getContentPane().add(lblNewLabel_5);
		
		textField_5 = new JTextField();
		textField_5.setBounds(602, 30, 86, 20);
		getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("SUBTOTAL:");
		lblNewLabel_6.setBounds(407, 148, 63, 14);
		getContentPane().add(lblNewLabel_6);
		
		textField_6 = new JTextField();
		textField_6.setBounds(464, 145, 86, 20);
		getContentPane().add(textField_6);
		textField_6.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("I.V.A:");
		lblNewLabel_7.setBounds(430, 173, 46, 14);
		getContentPane().add(lblNewLabel_7);
		
		textField_7 = new JTextField();
		textField_7.setBounds(464, 170, 86, 20);
		getContentPane().add(textField_7);
		textField_7.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("TOTAL:");
		lblNewLabel_8.setBounds(424, 198, 46, 14);
		getContentPane().add(lblNewLabel_8);
		
		textField_8 = new JTextField();
		textField_8.setBounds(464, 195, 86, 20);
		getContentPane().add(textField_8);
		textField_8.setColumns(10);
		model = (DefaultTableModel) tableproductos.getModel();
	}
}