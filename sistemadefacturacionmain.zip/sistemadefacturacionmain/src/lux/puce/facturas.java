package lux.puce;

public class facturas {
	private String codigo;
	private String Detalle;
	private float precio;
	private float cantidad;
	private float IVA;
	private float totaliva;
	private float total;

	
	public String getCodigo() {
		return codigo;
	}
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	public float getCantidad() {
		return cantidad;
	}
	public void setCantidad(float cantidad) {
		this.cantidad = cantidad;
	}
	public String getDetalle() {
		return Detalle;
	}
	public void setDetalle(String Detalle) {
		this.Detalle = Detalle;
	}
	public float getPrecio() {
		return precio;
	}
	public void setPrecio(float precio) {
		this.precio = precio;
	}
	public float getTotal() {
		return total;
	}
	public void setTotal(float total) {
		this.total = total;
	}
	public float getIVA() {
		return IVA;
	}
	public void setIVA(float IVA) {
		this.total = IVA;
	}
	public float getTotaliva() {
		return totaliva;
	}
	public void setTotaliva(float totaliva) {
		this.totaliva = totaliva;
	}
	
}

